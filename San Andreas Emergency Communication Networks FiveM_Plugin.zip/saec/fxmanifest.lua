fx_version 'cerulean'
game 'gta5'

author 'San Andreas Emergency Communication Networks'
description 'In-game interface for the San Andreas Emergency Communication Networks plugin'
version '1.2.3'

files {
	"client/nui/index.html",
	"Newtonsoft.Json.dll"
}

ui_page "client/nui/index.html"

client_scripts {
	'client/*.dll'
}

server_script {
	'server/*.dll'
}