To successfully install the script, you need to complete the following steps:

1. Open the 'sapr.cfg' file.
2. Set the 'sapr_communityId' to your TeamSpeak3 Server Unique Id. Example UID: VCCkXrMF6Ug8xKpoyzC9Smg94b0=
3. Change the other values to what you would like configured for your community. The commented lines provide more information for each setting.
4. Save your changes.
5. In your startup config, add 'exec {...path to sapr.cfg}'. The start command for the script is included in the bottom of the sapr.cfg file.
	Ex: exec resources/sapr/sapr.cfg
	If you have a subfolder between your startup config and the SAPR resource, be sure to include that: exec resources/[scripts]/sapr/sapr.cfg


If you are using OCRP's postals, or this script: https://forum.cfx.re/t/release-nearest-postal-script/293511
we have already done the work for you: https://github.com/AvalancheDevelopment/nearest-postal/archive/refs/heads/master.zip


If you get any errors in the server console when the script is starting, double check your community UID, and contact support in our discord: https://discord.gg/UMbfx7S8bw